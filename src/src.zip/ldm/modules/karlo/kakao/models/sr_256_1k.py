# ------------------------------------------------------------------------------------
# Karlo-v1.0.alpha
# Copyright (c) 2022 KakaoBrain. All Rights Reserved.
# ------------------------------------------------------------------------------------

from ldm.modules.karlo.kakao.models.sr_64_256 import SupRes64to256Progressive


class SupRes256to1kProgressive(SupRes64to256Progressive):
    pass  # no difference currently
